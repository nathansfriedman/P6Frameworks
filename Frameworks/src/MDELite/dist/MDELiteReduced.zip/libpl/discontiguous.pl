/** file   discontiguous.pl -- eliminates aggrevating warnings **/

:- style_check(-discontiguous).
