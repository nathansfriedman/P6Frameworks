/* file umlf.run.pl */

run:-printDbase(umlf).

