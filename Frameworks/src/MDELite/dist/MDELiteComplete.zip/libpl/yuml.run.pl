/* file: yuml.run.pl -- output the tables of a Yuml database */

run:-printDbase(yuml).
